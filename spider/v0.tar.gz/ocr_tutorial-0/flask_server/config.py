import os

# Grabs the folder where the script runs.
basedir = os.path.abspath(os.path.dirname(__file__))
